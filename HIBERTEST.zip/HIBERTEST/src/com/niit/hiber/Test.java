package com.niit.hiber;

public class Test {
	

	private int id;
	private String name,designation,salary;
	private String dob;
	
	/**
	 * @param id
	 * @param name
	 * @param designation
	 * @param salary
	 * @param dob
	 */
	public Test(int id, String name, String designation, String salary, String dob) {
		this.id = id;
		this.name = name;
		this.designation = designation;
		this.salary = salary;
		this.dob = dob;
	}

	public Test()
	{
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	
	

}
